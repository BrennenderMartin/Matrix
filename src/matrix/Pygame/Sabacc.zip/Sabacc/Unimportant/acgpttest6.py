import customtkinter as ctk

# Hauptfenster erstellen
ctk.set_appearance_mode("System")
root = ctk.CTk()
root.geometry("400x300")
root.title("Fenster mit Stop-Button")

# Funktion zum Beenden des Hauptfensters und des mainloop()
def stop_mainloop():
    root.destroy()  # Schließt das Fenster und beendet mainloop()

# Button zum Stoppen des mainloop
stop_button = ctk.CTkButton(root, text="Fenster schließen", command=stop_mainloop)
stop_button.pack(pady=20)

# Start des Hauptfensters
root.mainloop()
