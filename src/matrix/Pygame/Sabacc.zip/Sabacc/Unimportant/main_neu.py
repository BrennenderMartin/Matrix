"""Programm, da hier keine der Imports mehr funktioneieren"""
#import random
import pygame as pg

#Get some constants in da game
#define colors
BG = (0, 150, 0)
BG2 = (60, 114, 228)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
VIOLET = (255, 0, 255)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
#define screen size
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 600
#rest
FPS = 60
RUN = True
IND = 0
PRESSED = False
PLAYING = True


pg.init()

#hide mouse cursor
pg.mouse.set_visible(False)

def start():
    """Start function, deal 1 card to each player from the deck"""
    r = make_value_r()
    y = make_value_y()
    v.card_r.update(r)
    v.card_y.update(y)
start()
