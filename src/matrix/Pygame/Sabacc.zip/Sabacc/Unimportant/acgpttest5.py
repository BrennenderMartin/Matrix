import customtkinter as ctk

# customtkinter Theme und erstes Fenster erstellen
ctk.set_appearance_mode("System")
root = ctk.CTk()
root.geometry("400x300")
root.title("Altes Fenster")

# Funktion zum Öffnen eines neuen Fensters und Schließen des alten Fensters
def open_new_window():
    # Altes Fenster schließen
    root.destroy()

    # Neues Hauptfenster erstellen
    new_root = ctk.CTk()
    new_root.geometry("400x300")
    new_root.title("Neues Fenster")

    # Text oder Button im neuen Fenster (zur Verdeutlichung)
    label = ctk.CTkLabel(new_root, text="Dies ist das neue Hauptfenster")
    label.pack(pady=20)

    # Neues Hauptfenster starten
    new_root.mainloop()

# Button zum Öffnen des neuen Fensters und Schließen des alten Fensters
button = ctk.CTkButton(root, text="Neues Fenster öffnen und altes schließen", command=open_new_window)
button.pack(pady=20)

root.mainloop()
