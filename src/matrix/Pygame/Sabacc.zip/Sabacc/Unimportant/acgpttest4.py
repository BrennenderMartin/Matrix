import customtkinter as ctk

# customtkinter Theme und erstes Fenster erstellen
ctk.set_appearance_mode("System")
root = ctk.CTk()
root.geometry("400x300")
root.title("Altes Fenster")

# Funktion zum Öffnen eines neuen Fensters und Schließen des alten Fensters
def open_new_window():
    new_window = ctk.CTkToplevel()
    new_window.geometry("400x300")
    new_window.title("Neues Fenster")

    # Text oder Button im neuen Fenster (zur Verdeutlichung)
    label = ctk.CTkLabel(new_window, text="Dies ist das neue Fenster")
    label.pack(pady=20)

    # Altes Fenster schließen
    root.destroy()

# Button zum Öffnen des neuen Fensters und Schließen des alten Fensters
button = ctk.CTkButton(root, text="Neues Fenster öffnen und altes schließen", command=open_new_window)
button.pack(pady=20)

root.mainloop()
