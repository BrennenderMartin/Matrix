"""Programm was ich für Luis fucking neu schreiben musste"""
import random
import pygame as pg

"""Constants"""
#define colors
BG = (0, 150, 0)
BG2 = (60, 114, 228)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
VIOLET = (255, 0, 255)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

#define screen size
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 600

FPS = 60

RUN = True

IND = 0

PRESSED = False

PLAYING = True
def get_difference():
    """Gets the difference between the cards of the CPU"""
    x = 0
    return x
DIFFERENCE = get_difference()








"""Everything fucking else""" 

#screen
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pg.display.set_caption("SABACC")

#frame rate
clock = pg.time.Clock()

#create card pool
cards_r = [101, 102, 103, 104, 105, 106,
           101, 102, 103, 104, 105, 106,
           101, 102, 103, 104, 105, 106]
cards_y = [201, 202, 203, 204, 205, 206,
           201, 202, 203, 204, 205, 206,
           201, 202, 203, 204, 205, 206]

colors = ["red", "yellow"]
#value_r = f.make_value(len(cards_r)) + 100
#value_y = f.make_value(len(cards_y)) + 200

#create cards
"""Cards file"""
class Card(pg.sprite.Sprite):
    """Class of the Cards"""
    def __init__(self, x, y, type_card):
        pg.sprite.Sprite.__init__(self)
       
        #set up the image
        self.type_card = type_card
        self.dict_card = f"./cards/card_{self.type_card}.png"
        self.image = pg.image.load(self.dict_card).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
    
    def update(self, type_card):
        """Update function"""
        if type_card is None:
            self.dict_card = self.dict_card
        else:
            self.type_card = type_card
            self.dict_card = f"./cards/card_{self.type_card}.png"
        self.image = pg.image.load(self.dict_card).convert_alpha()

card = Card(200, 450, 0)

card_r = Card(200, 450, 0)
card_y = Card(400, 450, 0)

card_pr = Card(150, 250, 0)
card_py = Card(450, 250, 0)

card_dr = Card(250, 250, 0)
card_dy = Card(350, 250, 0)

card_1r = Card(5, 250, 1)
card_1y = Card(5, 350, 1)

#create buttons
"""Button file"""
class Button(pg.sprite.Sprite):
    """Class of the Buttons"""
    def __init__(self, x, y):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.image.load("./cards/cards_take.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.mask = pg.mask.from_surface(self.image)
        self.rect.center = (x, y)

button = Button(150, 350)

button_red = Button(150, 350)
button_yellow = Button(450, 350)
button_red_d = Button(250, 350)
button_yellow_d = Button(350, 350)

#create cursor
"""Cursors file"""
class Cursor(pg.sprite.Sprite):
    """Class of the Cursor"""
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.Surface((10, 10))
        self.rect = self.image.get_rect()
        self.image.fill(RED)
        self.mask = pg.mask.from_surface(self.image)

    def update(self, colour):
        """Update function"""
        pos = pg.mouse.get_pos()
        self.rect.center = (pos)
        self.image.fill(colour)

cursor = Cursor()

#create sprite groups
cards = pg.sprite.Group()
buttons = pg.sprite.Group()
cursors = pg.sprite.Group()
indicators = pg.sprite.Group()

#add instances to groups
cards.add(card_r, card_y, card_pr, card_py, card_dr, card_dy, card_1r, card_1y)
buttons.add(button_red, button_yellow, button_red_d, button_yellow_d)
cursors.add(cursor)










"""Functions file"""

def update():
    """Update function"""
    #make the cursor different colors, when hovering over the draw buttons
    col = None
    if pg.sprite.spritecollide(cursor, buttons, False, pg.sprite.collide_mask):
        if pg.sprite.spritecollide(button_red, cursors, False, pg.sprite.collide_mask):
            col = RED
        elif pg.sprite.spritecollide(button_yellow, cursors, False, pg.sprite.collide_mask):
            col = YELLOW
        elif pg.sprite.spritecollide(button_red_d, cursors, False, pg.sprite.collide_mask):
            col = CYAN
        elif pg.sprite.spritecollide(button_yellow_d, cursors, False, pg.sprite.collide_mask):
            col = VIOLET
    else:
        col = GREEN
    cursors.update(col)
    cards.update(None)

def draw():
    """Draw function"""
    cards.draw(screen)
    buttons.draw(screen)
    cursors.draw(screen)

def start():
    """Start function, deal 1 card to each player from the deck"""
    r = make_value_r()
    y = make_value_y()
    card_r.update(r)
    card_y.update(y)



def get_color():
    """Get color, to draw"""
    color = random.choice(colors)
    return color

def draw_card():
    """Action for the CPU"""
    color = get_color()
    if color == "red":
        value = card_r.type_card
        x = make_value_r()
        card_r.update(x)
        card_dr.update(value)
    elif color == "yellow":
        value = card_r.type_card
        x = make_value_r()
        card_r.update(x)
        card_dr.update(value)


def make_value_r():
    """Function, to makt the value for red cards"""
    index = random.randint(0, len(cards_r) - 1) 
    value = cards_r[index]
    del cards_r[index]
    return value

def make_value_y():
    """Function, to makt the value for yellow cards"""
    index = random.randint(0, len(cards_y) - 1) 
    value = cards_y[index]
    del cards_y[index]
    return value

def button_press():
    """A FUCKING BUTTON PRESS"""
    print("Button has been clicked")

def button_press_red():
    """Button function1"""
    value = card_r.type_card
    x = make_value_r()
    card_r.update(x)
    card_dr.update(value)

def button_press_yellow():
    """Button function2"""
    value = card_y.type_card
    x = make_value_y()
    card_y.update(x)
    card_dy.update(value)

def button_press_red_d():
    """Button function3"""
    value = card_r.type_card
    x = card_dr.type_card
    card_r.update(x)
    card_dr.update(value)

def button_press_yellow_d():
    """Button function4"""
    value = card_y.type_card
    x = card_dy.type_card
    card_y.update(x)
    card_dy.update(value)





"""All classes"""






"""CPU file"""
class CPU(pg.sprite.Sprite):
    """Class of the CPU, to have simple enemies"""
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        #draw new card (color at random)
        if PLAYING is True:
            draw_card()
        else:
            print("PLAYER has ended their move")
        #if differnce < 2 -> stop drawing
        if DIFFERENCE < 2:
            PLAYING = False








"""main file"""


pg.init()

#hide mouse cursor
pg.mouse.set_visible(False)

start()

pressed = False

while RUN:

    #setup (v)
    clock.tick(FPS)
    screen.fill(BG)

    #functions (f)
    draw()
    update()

    #event handler
    for event in pg.event.get():
        #Mousebutton events
        if event.type == pg.MOUSEBUTTONDOWN:
            #Button presses
            if event.button == 1:
                if pg.sprite.spritecollide(button_red, cursors, False, pg.sprite.collide_mask):
                    button_press_red()
                elif pg.sprite.spritecollide(button_yellow, cursors, False, pg.sprite.collide_mask):
                    button_press_yellow()
                elif pg.sprite.spritecollide(button_red_d, cursors, False, pg.sprite.collide_mask):
                    button_press_red_d()
                elif pg.sprite.spritecollide(button_yellow_d, cursors, False, pg.sprite.collide_mask):
                    button_press_yellow_d()

        #Key events
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_a:
                pressed = True
        
        #QUIT
        if event.type == pg.QUIT:
            run = False
        
    if pressed is True:
        print("Pressed a")
        pressed = False
    
    pg.display.flip()

pg.quit()