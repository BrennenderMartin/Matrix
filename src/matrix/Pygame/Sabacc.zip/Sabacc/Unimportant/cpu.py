"""The Class of the CPU of the enemies"""
#import constants as c
import constants as c
import functions as f
import pygame as pg

class CPU(pg.sprite.Sprite):
    """Class of the CPU, to have simple enemies"""
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        #draw new card (color at random)
        if c.PLAYING is True:
            f.draw_card()
        else:
            print("PLAYER has ended their move")
        #if differnce < 2 -> stop drawing
        if c.DIFFERENCE < 2:
            c.PLAYING = False
