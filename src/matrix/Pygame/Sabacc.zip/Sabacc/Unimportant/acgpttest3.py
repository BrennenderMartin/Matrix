import customtkinter as ctk

# customtkinter Theme und Fenster erstellen
ctk.set_appearance_mode("System")
root = ctk.CTk()
root.geometry("400x300")

# Grid-Konfiguration für zentrierte Ausrichtung
root.grid_columnconfigure(0, weight=1)
root.grid_rowconfigure(0, weight=1)

# Button erstellen und zentriert platzieren
button = ctk.CTkButton(root, text="Mittiger Button")
button.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")

root.mainloop()
