import customtkinter as ctk

# customtkinter Theme und Erscheinungsbild setzen
ctk.set_appearance_mode("System")  # Optionen: "System", "Dark", "Light"
ctk.set_default_color_theme("blue")  # Farbe der Komponenten

# Hauptfenster erstellen
root = ctk.CTk()
root.title("Hauptfenster")
root.geometry("400x300")

# Funktion zum Öffnen von Fenster 1
def open_window1():
    window1 = ctk.CTkToplevel(root)
    window1.title("Fenster 1 - 2 Eingabefelder")
    window1.geometry("300x200")
    
    # Zwei Eingabefelder erstellen
    label1 = ctk.CTkLabel(window1, text="Eingabe 1:")
    label1.pack(pady=10)
    entry1 = ctk.CTkEntry(window1)
    entry1.pack(pady=5)
    
    label2 = ctk.CTkLabel(window1, text="Eingabe 2:")
    label2.pack(pady=10)
    entry2 = ctk.CTkEntry(window1)
    entry2.pack(pady=5)

# Funktion zum Öffnen von Fenster 2
def open_window2():
    window2 = ctk.CTkToplevel(root)
    window2.title("Fenster 2 - 4 Eingabefelder")
    window2.geometry("300x300")
    
    # Vier Eingabefelder erstellen
    label1 = ctk.CTkLabel(window2, text="Eingabe 1:")
    label1.pack(pady=10)
    entry1 = ctk.CTkEntry(window2)
    entry1.pack(pady=5)
    
    label2 = ctk.CTkLabel(window2, text="Eingabe 2:")
    label2.pack(pady=10)
    entry2 = ctk.CTkEntry(window2)
    entry2.pack(pady=5)
    
    label3 = ctk.CTkLabel(window2, text="Eingabe 3:")
    label3.pack(pady=10)
    entry3 = ctk.CTkEntry(window2)
    entry3.pack(pady=5)
    
    label4 = ctk.CTkLabel(window2, text="Eingabe 4:")
    label4.pack(pady=10)
    entry4 = ctk.CTkEntry(window2)
    entry4.pack(pady=5)

# Buttons im Hauptfenster erstellen
button1 = ctk.CTkButton(root, text="Zu Fenster 1", command=open_window1)
button1.pack(pady=20)

button2 = ctk.CTkButton(root, text="Zu Fenster 2", command=open_window2)
button2.pack(pady=20)

# Hauptfenster ausführen
root.mainloop()
