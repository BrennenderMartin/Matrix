"""Class of the Cards"""
import pygame as pg

class Card(pg.sprite.Sprite):
    """Class of the Cards"""
    def __init__(self, x, y, type_card):
        pg.sprite.Sprite.__init__(self)

        #set up the image
        self.type_card = type_card
        self.dict_card = f"Pygame/Sabacc/cards/card_{self.type_card}.png"
        self.image = pg.image.load(self.dict_card).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def update(self, type_card):
        """Update function"""
        if type_card is None:
            self.dict_card = self.dict_card
        else:
            self.type_card = type_card
            self.dict_card = f"Pygame/Sabacc/cards/card_{self.type_card}.png"
        self.image = pg.image.load(self.dict_card).convert_alpha()
