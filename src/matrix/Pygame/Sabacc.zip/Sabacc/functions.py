"""All functions"""
import random
import constants as c
import variables as v
import pygame as pg

def update():
    """Update function"""
    #make the cursor different colors, when hovering over the draw buttons
    col = None
    if pg.sprite.spritecollide(v.cursor, v.buttons, False, pg.sprite.collide_mask):
        if pg.sprite.spritecollide(v.button_red, v.cursors, False, pg.sprite.collide_mask):
            col = c.RED
        elif pg.sprite.spritecollide(v.button_yellow, v.cursors, False, pg.sprite.collide_mask):
            col = c.YELLOW
        elif pg.sprite.spritecollide(v.button_red_d, v.cursors, False, pg.sprite.collide_mask):
            col = c.CYAN
        elif pg.sprite.spritecollide(v.button_yellow_d, v.cursors, False, pg.sprite.collide_mask):
            col = c.VIOLET
    elif pg.sprite.spritecollide(v.cursor, v.cards, False, pg.sprite.collide_mask):
        if pg.sprite.spritecollide(v.card, v.cursors, False, pg.sprite.collide_mask):
            col = c.BLUE
        elif pg.sprite.spritecollide(v.card_r, v.cursors, False, pg.sprite.collide_mask):
            col = c.RED
        elif pg.sprite.spritecollide(v.card_y, v.cursors, False, pg.sprite.collide_mask):
            col = c.YELLOW
        else:
            col = c.GREEN
    else:
        col = c.GREEN
    v.cursors.update(col)
    v.cards.update(None)
    v.coins.update()

def draw():
    """Draw function"""
    v.cards.draw(v.screen)
    v.buttons.draw(v.screen)
    v.cursors.draw(v.screen)
    v.coins.draw(v.screen)

def start():
    """Start function, deal 1 card to each player from the deck"""
    r = make_value_r()
    y = make_value_y()
    v.card_r.update(r)
    v.card_y.update(y)

def get_color():
    """Get color, to draw"""
    color = random.choice(v.colors)
    return color

def draw_card():
    """Action for the CPU ONLY CPU!!!ONLY CPU!!!ONLY CPU!!!ONLY CPU!!!ONLY CPU!!!ONLY CPU!!!"""
    color = get_color()
    if color == "red":
        value = v.card_r.type_card
        x = make_value_r()
        v.card_r.update(x)
        v.card_dr.update(value)
    elif color == "yellow":
        value = v.card_r.type_card
        x = make_value_r()
        v.card_r.update(x)
        v.card_dr.update(value)

#Make Values
def make_value_r():
    """Function, to makt the value for red cards"""
    if len(v.cards_r) - 1 == 0:
        print("New Pile")
        v.cards_r = v.backuppile_r
        index = random.randint(0, len(v.cards_r) - 1)
        value = v.cards_r[index]
        del v.cards_r[index]
        return value
        #c.RUN = False
    else:
        index = random.randint(0, len(v.cards_r) - 1)
        value = v.cards_r[index]
        del v.cards_r[index]
        return value

def make_value_y():
    """Function, to makt the value for yellow cards"""
    if len(v.cards_y) - 1 == 0:
        print("New Pile")
        v.cards_y = v.backuppile_y
        index = random.randint(0, len(v.cards_y) - 1)
        value = v.cards_y[index]
        del v.cards_y[index]
        return value
        #c.RUN = False
    else:
        index = random.randint(0, len(v.cards_y) - 1)
        value = v.cards_y[index]
        del v.cards_y[index]
        return value

#All Button Presses
def button_press():
    """A FUCKING BUTTON PRESS"""
    print("Button has been clicked")

def button_press_red():
    """Drawing a new card for red"""
    v.coin.type_tag -= 1
    c.COLOR = 1
    c.NEW_VALUE = make_value_r()
    v.card.update(c.NEW_VALUE)

def switch_card():
    """Function if you choose to take the card you just drew"""
    if c.COLOR == 0:
        print("It does nothing!!!")
    elif c.COLOR == 1:
        #What happens if the color is red
        old_value = v.card_r.type_card
        v.card_r.update(c.NEW_VALUE)
        v.card_dr.update(old_value)
        v.card.update(0)
    elif c.COLOR == 2:
        #What happens if the color is black / yellow
        old_value = v.card_y.type_card
        v.card_y.update(c.NEW_VALUE)
        v.card_dy.update(old_value)
        v.card.update(0)
    c.COLOR = 0
    c.NEW_VALUE = 0

def button_press_yellow():
    """Drawing a new card for red"""
    v.coin.type_tag -= 1
    c.COLOR = 2
    c.NEW_VALUE = make_value_y()
    v.card.update(c.NEW_VALUE)

def keep_card_r():
    """Function, when you choose, to keep the card, instead of taking the new card(In red)"""
    v.card_r.update(None)
    v.card_dr.update(c.NEW_VALUE)
    v.card.update(0)
    c.COLOR = 0

def keep_card_y():
    """Function, when you choose, to keep the card, instead of taking the new card(In yellow)"""
    v.card_y.update(None)
    v.card_dy.update(c.NEW_VALUE)
    v.card.update(0)
    c.COLOR = 0

def button_press_red_d():
    """Button function3"""
    v.coin.type_tag -= 1
    value = v.card_r.type_card
    x = v.card_dr.type_card
    v.card_r.update(x)
    v.card_dr.update(value)

def button_press_yellow_d():
    """Button function4"""
    v.coin.type_tag -= 1
    value = v.card_y.type_card
    x = v.card_dy.type_card
    v.card_y.update(x)
    v.card_dy.update(value)
