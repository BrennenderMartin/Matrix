"""Class of the Coins"""
import pygame as pg

class Coins(pg.sprite.Sprite):
    """Class of the Coins"""
    def __init__(self, x, y):
        pg.sprite.Sprite.__init__(self)

        #set up the image
        self.type_tag = 4
        self.dict_card = f"Pygame/Sabacc/cards/tag_{self.type_tag}.png"
        self.image = pg.image.load(self.dict_card).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def update(self):
        """Update function"""
        if self.type_tag >= 0:
            self.dict_card = f"Pygame/Sabacc/cards/tag_{self.type_tag}.png"
        #else:
            #c.RUN = False
        self.image = pg.image.load(self.dict_card).convert_alpha()
