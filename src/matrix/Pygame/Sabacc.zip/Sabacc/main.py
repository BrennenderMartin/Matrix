"""Main Programm, where the Game loop is running"""
import constants as c
import variables as v
import functions as f
import pygame as pg

v.app.mainloop()

pg.init()

#hide mouse cursor (only necessary when you want to see the color, else indent update cursor)
pg.mouse.set_visible(False)

f.start()

while c.RUN:

    #setup (v)
    v.clock.tick(c.FPS)
    v.screen.fill(c.BG)

    #functions (f)
    f.draw()
    f.update()

    #event handler
    for event in pg.event.get():
        #Mousebutton events
        if event.type == pg.MOUSEBUTTONDOWN:
            #Button presses
            if event.button == 1:
                #Left mouse button presses
                if pg.sprite.spritecollide(v.button_red, v.cursors,
                                           False, pg.sprite.collide_mask):
                    f.button_press_red()
                elif pg.sprite.spritecollide(v.button_yellow, v.cursors,
                                             False, pg.sprite.collide_mask):
                    f.button_press_yellow()
                elif pg.sprite.spritecollide(v.button_red_d, v.cursors,
                                             False, pg.sprite.collide_mask):
                    f.button_press_red_d()
                elif pg.sprite.spritecollide(v.button_yellow_d, v.cursors,
                                             False, pg.sprite.collide_mask):
                    f.button_press_yellow_d()
                elif pg.sprite.spritecollide(v.card, v.cursors,
                                             False, pg.sprite.collide_mask):
                    f.switch_card()
                elif pg.sprite.spritecollide(v.card_r, v.cursors,
                                             False, pg.sprite.collide_mask):
                    f.keep_card_r()
                elif pg.sprite.spritecollide(v.card_y, v.cursors,
                                             False, pg.sprite.collide_mask):
                    f.keep_card_y()

        #Key events
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_a:
                c.PRESSED = True

        #QUIT
        if event.type == pg.QUIT:
            c.RUN = False

    if c.PRESSED is True:
        print("Pressed a")
        c.PRESSED = False

    pg.display.flip()

pg.quit()
