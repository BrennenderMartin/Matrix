"""Class of the Cursor"""
import constants as c
import pygame as pg

class Cursor(pg.sprite.Sprite):
    """Class of the Cursor"""
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.Surface((10, 10))
        self.rect = self.image.get_rect()
        self.image.fill(c.RED)
        self.mask = pg.mask.from_surface(self.image)

    def update(self, colour):
        """Update function"""
        pos = pg.mouse.get_pos()
        self.rect.center = pos
        self.image.fill(colour)
