"""All variables"""
import constants as c
import cards as cd
import button as b
import cursor as cr
import coins as co
import addon as a
import pygame as pg


#screen
screen = pg.display.set_mode((c.SCREEN_WIDTH, c.SCREEN_HEIGHT))
pg.display.set_caption("SABACC")

#frame rate
clock = pg.time.Clock()

#customtkinter
app = a.App()

#create card pool
cards_r = [100, 101, 102, 103, 104, 105, 106, 113,
           100, 101, 102, 103, 104, 105, 106, 113,
           100, 101, 102, 103, 104, 105, 106, 113]
cards_y = [200, 201, 202, 203, 204, 205, 206, 213,
           200, 201, 202, 203, 204, 205, 206, 213,
           200, 201, 202, 203, 204, 205, 206, 213]

backuppile_r = [100, 101, 102, 103, 104, 105, 106, 113,
                100, 101, 102, 103, 104, 105, 106, 113,
                100, 101, 102, 103, 104, 105, 106, 113]
backuppile_y = [200, 201, 202, 203, 204, 205, 206, 213,
                200, 201, 202, 203, 204, 205, 206, 213,
                200, 201, 202, 203, 204, 205, 206, 213]

colors = ["red", "yellow"]
#value_r = f.make_value(len(cards_r)) + 100
#value_y = f.make_value(len(cards_y)) + 200

#create coin
coin = co.Coins(25, 25)

#create cards
card = cd.Card(300, 450, 0)

card_r = cd.Card(200, 450, 0)
card_y = cd.Card(400, 450, 0)

card_dr = cd.Card(250, 250, 0)
card_dy = cd.Card(350, 250, 0)

card_pr = cd.Card(150, 250, 0)
card_py = cd.Card(450, 250, 0)

card_1r = cd.Card(5, 250, 1)
card_1y = cd.Card(5, 350, 1)

card_2r = cd.Card(250, 5, 0)
card_2y = cd.Card(350, 5, 0)

card_3r = cd.Card(595, 250, 1)
card_3y = cd.Card(595, 350, 1)

#create buttons
button = b.Button(150, 350)

button_red = b.Button(150, 350)
button_yellow = b.Button(450, 350)
button_red_d = b.Button(250, 350)
button_yellow_d = b.Button(350, 350)

#create cursor
cursor = cr.Cursor()

#create sprite groups
cards = pg.sprite.Group()
buttons = pg.sprite.Group()
cursors = pg.sprite.Group()
coins = pg.sprite.Group()

#add instances to groups
cards.add(card,
          card_r, card_y,
          card_pr, card_py,
          card_dr, card_dy,
          card_1r, card_1y,
          card_2r, card_2y,
          card_3r, card_3y)
buttons.add(button_red,
            button_yellow,
            button_red_d,
            button_yellow_d)
cursors.add(cursor)
coins.add(coin)
