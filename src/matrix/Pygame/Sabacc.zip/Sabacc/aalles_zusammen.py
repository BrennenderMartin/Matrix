"""Alle dateien zusammengefügt, um eine große zu machen"""
import random
import customtkinter as ctk
import pygame as pg

#1. l. 018: Setup (ctk.,,,; pg.init; ect.)
#2. l. 025: Constants
#3. l. 055: Variables (without anything of the classes)
#4. l. 080: Class CTK
#5. l. 220: Class Button
#6. l. 245: Class Cards
#7. l. 300: Class Coins
#8. l. 328: Class Cursor
#9. l. 352: Functions
#0. l. 501: main loop
#Total lines: 560

ctk.set_appearance_mode("System")  # Modes: "System" (standard), "Dark", "Light"
ctk.set_default_color_theme("blue")  # Themes: "blue" (standard), "green", "dark-blue"

pg.init()
pg.mouse.set_visible(False)


#define colors
BG = (0, 150, 0)
BG2 = (60, 114, 228)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
CYAN = (0, 255, 255)
VIOLET = (255, 0, 255)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

#define screen size
SCREEN_WIDTH = 600
SCREEN_HEIGHT = 600

#color for the draw function, with 1 meaning red and 2 meaning black / yellow
COLOR = 0

#variable, to temporarily save the value for the card
NEW_VALUE = 0

#define rest
FPS = 60
RUN = True
IND = 0
PRESSED = False
PLAYING = True


#screen
screen = pg.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pg.display.set_caption("SABACC")

#frame rate
clock = pg.time.Clock()

#create card pool
cards_r = [100, 101, 102, 103, 104, 105, 106, 113,
           100, 101, 102, 103, 104, 105, 106, 113,
           100, 101, 102, 103, 104, 105, 106, 113]
cards_y = [200, 201, 202, 203, 204, 205, 206, 213,
           200, 201, 202, 203, 204, 205, 206, 213,
           200, 201, 202, 203, 204, 205, 206, 213]

backuppile_r = [100, 101, 102, 103, 104, 105, 106, 113,
                100, 101, 102, 103, 104, 105, 106, 113,
                100, 101, 102, 103, 104, 105, 106, 113]
backuppile_y = [200, 201, 202, 203, 204, 205, 206, 213,
                200, 201, 202, 203, 204, 205, 206, 213,
                200, 201, 202, 203, 204, 205, 206, 213]

colors = ["red", "yellow"]


class App(ctk.CTk):
    """Mit ctk erstelle Klasse, welche die Fenster öffnet, um einer Lobby zu joinen/ erstellen"""
    def __init__(self):
        super().__init__()
        #make variables
        self.login_code = 0
        self.w1var1 = 0
        self.w1var2 = 0
        self.w2var1 = 0
        self.w2var2 = 0
        self.w2var3 = 0
        self.w2var4 = 0

        # configure window
        self.title("Sabacc.py")
        #self.geometry(f"{300}x{200}")

        # create sidebar frame with widgets
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.logo_label = ctk.CTkLabel(self,
                                       width=200,
                                       text="Sabacc",
                                       font=ctk.CTkFont(size=20, weight="bold"))
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="nsew")

        self.sidebar_button_1 = ctk.CTkButton(self,
                                              text="Lobby joinen",
                                              width=200,
                                              command=self.open_window1)
        self.sidebar_button_1.grid(row=1, column=0, padx=20, pady=10, sticky="nsew")

        self.sidebar_button_2 = ctk.CTkButton(self,
                                              text="Lobby erstellen",
                                              width=200,
                                              command=self.open_window2)
        self.sidebar_button_2.grid(row=2, column=0, padx=20, pady=(10, 20), sticky="nsew")

    def open_window1(self):
        """Funktion zum Öffnen von Fenster 1"""
        window1 = ctk.CTkToplevel(self)
        window1.title("Fenster 1 - Join Lobby")
        window1.geometry("300x250")

        # Zwei Eingabefelder erstellen
        label1 = ctk.CTkLabel(window1, text="Code:")
        label1.pack(pady=5)
        entry1 = ctk.CTkEntry(window1)
        entry1.pack(pady=5)

        label2 = ctk.CTkLabel(window1, text="Username:")
        label2.pack(pady=5)
        entry2 = ctk.CTkEntry(window1)
        entry2.pack(pady=5)

        # Funktion, um Werte auszulesen und anzuzeigen
        def show_values():
            self.w1var1 = entry1.get()
            self.w1var2 = entry2.get()
            text = f"Code: {self.w1var1}, Username: {self.w1var2}"
            output_label.configure(text)
            print(text)

            #Fenster schließen
            self.destroy()

        def exiting():
            """closes the second input window"""
            window1.destroy()

        # Button zum Auslesen der Werte
        show_button = ctk.CTkButton(window1, text="Werte anzeigen", command=show_values)
        show_button.pack(pady=10)

        exit_button = ctk.CTkButton(window1, text="Zurück", command=exiting)
        exit_button.pack(pady=10)

        # Label für Ausgabe der Werte
        output_label = ctk.CTkLabel(window1, text="")
        output_label.pack(pady=5)

    def open_window2(self):
        """Funktion zum Öffnen von Fenster 2"""
        window2 = ctk.CTkToplevel(self)
        window2.title("Fenster 2 - Lobby erstellen")
        window2.geometry("300x400")

        # Vier Eingabefelder erstellen
        label1 = ctk.CTkLabel(window2, text="Anzahl Spieler:")
        label1.pack(pady=5)
        entry1 = ctk.CTkEntry(window2)
        entry1.pack(pady=5)

        label2 = ctk.CTkLabel(window2, text="Anzahl Leben:")
        label2.pack(pady=5)
        entry2 = ctk.CTkEntry(window2)
        entry2.pack(pady=5)

        label3 = ctk.CTkLabel(window2, text="Anzahl Runden:")
        label3.pack(pady=5)
        entry3 = ctk.CTkEntry(window2)
        entry3.pack(pady=5)

        label4 = ctk.CTkLabel(window2, text="Anzahl Subrunden:")
        label4.pack(pady=5)
        entry4 = ctk.CTkEntry(window2)
        entry4.pack(pady=5)

        # Funktion, um Werte auszulesen und anzuzeigen
        def show_values():
            self.w2var1 = entry1.get()
            self.w2var2 = entry2.get()
            self.w2var3 = entry3.get()
            self.w2var4 = entry4.get()
            text = f"Spieler: {self.w2var1}, Leben: {self.w2var2}, Runden: {self.w2var3}, Subrunden: {self.w2var4}"
            output_label.configure(text)
            print(text)

            #Fenster schließen
            self.destroy()

        def exiting():
            """closes the second input window"""
            window2.destroy()
        # Button zum Auslesen der Werte
        show_button = ctk.CTkButton(window2, text="Werte anzeigen", command=show_values)
        show_button.pack(pady=10)

        show_button = ctk.CTkButton(window2, text="Zurück", command=exiting)
        show_button.pack(pady=10)

        # Label für Ausgabe der Werte
        output_label = ctk.CTkLabel(window2, text="")
        output_label.pack(pady=5)

#customtkinter
app = App()


class Button(pg.sprite.Sprite):
    """Class of the Buttons"""
    def __init__(self, x, y):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.image.load("Pygame/Sabacc/cards/cards_take.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.mask = pg.mask.from_surface(self.image)
        self.rect.center = (x, y)

#create buttons
button = Button(150, 350)

button_red = Button(150, 350)
button_yellow = Button(450, 350)
button_red_d = Button(250, 350)
button_yellow_d = Button(350, 350)

#create sprite groups
buttons = pg.sprite.Group()
buttons.add(button_red,
            button_yellow,
            button_red_d,
            button_yellow_d)


class Card(pg.sprite.Sprite):
    """Class of the Cards"""
    def __init__(self, x, y, type_card):
        pg.sprite.Sprite.__init__(self)

        #set up the image
        self.type_card = type_card
        self.dict_card = f"Pygame/Sabacc/cards/card_{self.type_card}.png"
        self.image = pg.image.load(self.dict_card).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def update(self, type_card):
        """Update function"""
        if type_card is None:
            self.dict_card = self.dict_card
        else:
            self.type_card = type_card
            self.dict_card = f"Pygame/Sabacc/cards/card_{self.type_card}.png"
        self.image = pg.image.load(self.dict_card).convert_alpha()

#create cards
card = Card(300, 450, 0)

card_r = Card(200, 450, 0)
card_y = Card(400, 450, 0)

card_dr = Card(250, 250, 0)
card_dy = Card(350, 250, 0)

card_pr = Card(150, 250, 0)
card_py = Card(450, 250, 0)

card_1r = Card(5, 250, 1)
card_1y = Card(5, 350, 1)

card_2r = Card(250, 5, 0)
card_2y = Card(350, 5, 0)

card_3r = Card(595, 250, 1)
card_3y = Card(595, 350, 1)

#create sprite groups
cards = pg.sprite.Group()

#add instances to groups
cards.add(card,
          card_r, card_y,
          card_pr, card_py,
          card_dr, card_dy,
          card_1r, card_1y,
          card_2r, card_2y,
          card_3r, card_3y)


class Coins(pg.sprite.Sprite):
    """Class of the Coins"""
    def __init__(self, x, y):
        pg.sprite.Sprite.__init__(self)

        #set up the image
        self.type_tag = 4
        self.dict_card = f"Pygame/Sabacc/cards/tag_{self.type_tag}.png"
        self.image = pg.image.load(self.dict_card).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def update(self):
        """Update function"""
        if self.type_tag >= 0:
            self.dict_card = f"Pygame/Sabacc/cards/tag_{self.type_tag}.png"
        #else:
            #c.RUN = False
        self.image = pg.image.load(self.dict_card).convert_alpha()

#create coin
coin = Coins(25, 25)

#create sprite groups
coins = pg.sprite.Group()
coins.add(coin)


class Cursor(pg.sprite.Sprite):
    """Class of the Cursor"""
    def __init__(self):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.Surface((10, 10))
        self.rect = self.image.get_rect()
        self.image.fill(RED)
        self.mask = pg.mask.from_surface(self.image)

    def update(self, colour):
        """Update function"""
        pos = pg.mouse.get_pos()
        self.rect.center = pos
        self.image.fill(colour)

#create cursor
cursor = Cursor()

#create sprite groups
cursors = pg.sprite.Group()

cursors.add(cursor)


def update():
    """Update function"""
    #make the cursor different colors, when hovering over the draw buttons
    col = None
    if pg.sprite.spritecollide(cursor, buttons, False, pg.sprite.collide_mask):
        if pg.sprite.spritecollide(button_red, cursors, False, pg.sprite.collide_mask):
            col = RED
        elif pg.sprite.spritecollide(button_yellow, cursors, False, pg.sprite.collide_mask):
            col = YELLOW
        elif pg.sprite.spritecollide(button_red_d, cursors, False, pg.sprite.collide_mask):
            col = CYAN
        elif pg.sprite.spritecollide(button_yellow_d, cursors, False, pg.sprite.collide_mask):
            col = VIOLET
    elif pg.sprite.spritecollide(cursor, cards, False, pg.sprite.collide_mask):
        if pg.sprite.spritecollide(card, cursors, False, pg.sprite.collide_mask):
            col = BLUE
        elif pg.sprite.spritecollide(card_r, cursors, False, pg.sprite.collide_mask):
            col = RED
        elif pg.sprite.spritecollide(card_y, cursors, False, pg.sprite.collide_mask):
            col = YELLOW
        else:
            col = GREEN
    else:
        col = GREEN
    cursors.update(col)
    cards.update(None)
    coins.update()

def draw():
    """Draw function"""
    cards.draw(screen)
    buttons.draw(screen)
    cursors.draw(screen)
    coins.draw(screen)

def start():
    """Start function, deal 1 card to each player from the deck"""
    r = make_value_r()
    y = make_value_y()
    card_r.update(r)
    card_y.update(y)

def get_color():
    """Get color, to draw"""
    color = random.choice(colors)
    return color

#Make Values
def make_value_r():
    """Function, to makt the value for red cards"""
    if len(cards_r) - 1 == 0:
        print("New Pile")
        cards_r = backuppile_r
        index = random.randint(0, len(cards_r) - 1)
        value = cards_r[index]
        del cards_r[index]
        return value
        #c.RUN = False
    else:
        index = random.randint(0, len(cards_r) - 1)
        value = cards_r[index]
        del cards_r[index]
        return value

def make_value_y():
    """Function, to makt the value for yellow cards"""
    if len(cards_y) - 1 == 0:
        print("New Pile")
        cards_y = backuppile_y
        index = random.randint(0, len(cards_y) - 1)
        value = cards_y[index]
        del cards_y[index]
        return value
        #c.RUN = False
    else:
        index = random.randint(0, len(cards_y) - 1)
        value = cards_y[index]
        del cards_y[index]
        return value

#All Button Presses
def button_press():
    """A FUCKING BUTTON PRESS"""
    print("Button has been clicked")

def button_press_red():
    """Drawing a new card for red"""
    coin.type_tag -= 1
    COLOR = 1
    NEW_VALUE = make_value_r()
    card.update(NEW_VALUE)

def switch_card():
    """Function if you choose to take the card you just drew"""
    if COLOR == 0:
        print("It does nothing!!!")
    elif COLOR == 1:
        #What happens if the color is red
        old_value = card_r.type_card
        card_r.update(NEW_VALUE)
        card_dr.update(old_value)
        card.update(0)
    elif COLOR == 2:
        #What happens if the color is black / yellow
        old_value = card_y.type_card
        card_y.update(NEW_VALUE)
        card_dy.update(old_value)
        card.update(0)
    COLOR = 0
    NEW_VALUE = 0

def button_press_yellow():
    """Drawing a new card for red"""
    coin.type_tag -= 1
    COLOR = 2
    NEW_VALUE = make_value_y()
    card.update(NEW_VALUE)

def keep_card_r():
    """Function, when you choose, to keep the card, instead of taking the new card(In red)"""
    card_r.update(None)
    card_dr.update(NEW_VALUE)
    card.update(0)
    COLOR = 0

def keep_card_y():
    """Function, when you choose, to keep the card, instead of taking the new card(In yellow)"""
    card_y.update(None)
    card_dy.update(NEW_VALUE)
    card.update(0)
    COLOR = 0

def button_press_red_d():
    """Button function3"""
    coin.type_tag -= 1
    value = card_r.type_card
    x = card_dr.type_card
    card_r.update(x)
    card_dr.update(value)

def button_press_yellow_d():
    """Button function4"""
    coin.type_tag -= 1
    value = card_y.type_card
    x = card_dy.type_card
    card_y.update(x)
    card_dy.update(value)


app.mainloop()

start()

while RUN:

    #setup (v)
    clock.tick(FPS)
    screen.fill(BG)

    #functions (f)
    draw()
    update()

    #event handler
    for event in pg.event.get():
        #Mousebutton events
        if event.type == pg.MOUSEBUTTONDOWN:
            #Button presses
            if event.button == 1:
                #Left mouse button presses
                if pg.sprite.spritecollide(button_red, cursors,
                                           False, pg.sprite.collide_mask):
                    button_press_red()
                elif pg.sprite.spritecollide(button_yellow, cursors,
                                             False, pg.sprite.collide_mask):
                    button_press_yellow()
                elif pg.sprite.spritecollide(button_red_d, cursors,
                                             False, pg.sprite.collide_mask):
                    button_press_red_d()
                elif pg.sprite.spritecollide(button_yellow_d, cursors,
                                             False, pg.sprite.collide_mask):
                    button_press_yellow_d()
                elif pg.sprite.spritecollide(card, cursors,
                                             False, pg.sprite.collide_mask):
                    switch_card()
                elif pg.sprite.spritecollide(card_r, cursors,
                                             False, pg.sprite.collide_mask):
                    keep_card_r()
                elif pg.sprite.spritecollide(card_y, cursors,
                                             False, pg.sprite.collide_mask):
                    keep_card_y()

        #Key events
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_a:
                PRESSED = True

        #QUIT
        if event.type == pg.QUIT:
            RUN = False

    if PRESSED is True:
        print("Pressed a")
        PRESSED = False

    pg.display.flip()

pg.quit()
