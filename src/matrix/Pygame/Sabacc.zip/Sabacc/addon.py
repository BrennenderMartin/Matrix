"""Alles was nach Luis Version von mir hinzugefügt wurde"""
import customtkinter as ctk

ctk.set_appearance_mode("System")  # Modes: "System" (standard), "Dark", "Light"
ctk.set_default_color_theme("blue")  # Themes: "blue" (standard), "green", "dark-blue"

class App(ctk.CTk):
    """Mit ctk erstelle Klasse, welche die Fenster öffnet, um einer Lobby zu joinen/ erstellen"""
    def __init__(self):
        super().__init__()
        #make variables
        self.login_code = 0
        self.w1var1 = 0
        self.w1var2 = 0
        self.w2var1 = 0
        self.w2var2 = 0
        self.w2var3 = 0
        self.w2var4 = 0

        # configure window
        self.title("Sabacc.py")
        #self.geometry(f"{300}x{200}")

        # create sidebar frame with widgets
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self.logo_label = ctk.CTkLabel(self,
                                       width=200,
                                       text="Sabacc",
                                       font=ctk.CTkFont(size=20, weight="bold"))
        self.logo_label.grid(row=0, column=0, padx=20, pady=(20, 10), sticky="nsew")

        self.sidebar_button_1 = ctk.CTkButton(self,
                                              text="Lobby joinen",
                                              width=200,
                                              command=self.open_window1)
        self.sidebar_button_1.grid(row=1, column=0, padx=20, pady=10, sticky="nsew")

        self.sidebar_button_2 = ctk.CTkButton(self,
                                              text="Lobby erstellen",
                                              width=200,
                                              command=self.open_window2)
        self.sidebar_button_2.grid(row=2, column=0, padx=20, pady=(10, 20), sticky="nsew")

    def open_window1(self):
        """Funktion zum Öffnen von Fenster 1"""
        window1 = ctk.CTkToplevel(self)
        window1.title("Fenster 1 - Join Lobby")
        window1.geometry("300x250")

        # Zwei Eingabefelder erstellen
        label1 = ctk.CTkLabel(window1, text="Code:")
        label1.pack(pady=5)
        entry1 = ctk.CTkEntry(window1)
        entry1.pack(pady=5)

        label2 = ctk.CTkLabel(window1, text="Username:")
        label2.pack(pady=5)
        entry2 = ctk.CTkEntry(window1)
        entry2.pack(pady=5)

        # Funktion, um Werte auszulesen und anzuzeigen
        def show_values():
            self.w1var1 = entry1.get()
            self.w1var2 = entry2.get()
            text = f"Code: {self.w1var1}, Username: {self.w1var2}"
            output_label.configure(text)
            print(text)

            #Fenster schließen
            self.destroy()

        def exiting():
            """closes the second input window"""
            window1.destroy()

        # Button zum Auslesen der Werte
        show_button = ctk.CTkButton(window1, text="Werte anzeigen", command=show_values)
        show_button.pack(pady=10)

        exit_button = ctk.CTkButton(window1, text="Zurück", command=exiting)
        exit_button.pack(pady=10)

        # Label für Ausgabe der Werte
        output_label = ctk.CTkLabel(window1, text="")
        output_label.pack(pady=5)

    def open_window2(self):
        """Funktion zum Öffnen von Fenster 2"""
        window2 = ctk.CTkToplevel(self)
        window2.title("Fenster 2 - Lobby erstellen")
        window2.geometry("300x400")

        # Vier Eingabefelder erstellen
        label1 = ctk.CTkLabel(window2, text="Anzahl Spieler:")
        label1.pack(pady=5)
        entry1 = ctk.CTkEntry(window2)
        entry1.pack(pady=5)

        label2 = ctk.CTkLabel(window2, text="Anzahl Leben:")
        label2.pack(pady=5)
        entry2 = ctk.CTkEntry(window2)
        entry2.pack(pady=5)

        label3 = ctk.CTkLabel(window2, text="Anzahl Runden:")
        label3.pack(pady=5)
        entry3 = ctk.CTkEntry(window2)
        entry3.pack(pady=5)

        label4 = ctk.CTkLabel(window2, text="Anzahl Subrunden:")
        label4.pack(pady=5)
        entry4 = ctk.CTkEntry(window2)
        entry4.pack(pady=5)

        # Funktion, um Werte auszulesen und anzuzeigen
        def show_values():
            self.w2var1 = entry1.get()
            self.w2var2 = entry2.get()
            self.w2var3 = entry3.get()
            self.w2var4 = entry4.get()
            text = f"Spieler: {self.w2var1}, Leben: {self.w2var2}, Runden: {self.w2var3}, Subrunden: {self.w2var4}"
            output_label.configure(text)
            print(text)

            #Fenster schließen
            self.destroy()

        def exiting():
            """closes the second input window"""
            window2.destroy()
        # Button zum Auslesen der Werte
        show_button = ctk.CTkButton(window2, text="Werte anzeigen", command=show_values)
        show_button.pack(pady=10)

        show_button = ctk.CTkButton(window2, text="Zurück", command=exiting)
        show_button.pack(pady=10)

        # Label für Ausgabe der Werte
        output_label = ctk.CTkLabel(window2, text="")
        output_label.pack(pady=5)
