"""Class of the Buttons"""
import pygame as pg

class Button(pg.sprite.Sprite):
    """Class of the Buttons"""
    def __init__(self, x, y):
        pg.sprite.Sprite.__init__(self)
        self.image = pg.image.load("Pygame/Sabacc/cards/cards_take.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.mask = pg.mask.from_surface(self.image)
        self.rect.center = (x, y)